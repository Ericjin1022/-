#include<stdio.h>
#include<stdlib.h>
#include<memory.h>

typedef struct Edge
{
	int from;
	int to;
	int weight;
};

Edge edge[100] = { {0,0,0}, };
int getRoot[100] = { 0, };

int main()
{
	
	FILE* fin = fopen("input.txt", "r");
	int nv, ne;
	int t1=0, t2=0, t3=0;
	fscanf(fin, "%d %d", &nv, &ne);
	for (int i = 0; i < ne; i++)
	{
		fscanf(fin, "%d%d%d", &t1, &t2, &t3);
		edge[i].from=t1;
		edge[i].to=t2;
		edge[i].weight=t3;
	}
	int i, j;
	for (i = 0; i < ne-1; i++)
	{
		for (j = 0; j < ne-1-i; j++)
		{
			if (edge[j].weight>edge[j+1].weight)
			{
				int t = edge[j].weight;
				edge[j].weight = edge[j + 1].weight;
				edge[j + 1].weight = t;
			}
		}
	}
	for (int i = 0; i < nv; i++)
	{
		getRoot[i] = i;
	}
	int sum=0;
	for (int i = 0; i < ne; i++)
	{
		int root1, root2;
		int temp = edge[i].from;
		while (1)
		{
			if (getRoot[temp] == temp)
			{
				root1 = temp;
				break;
			}
			else
			{
				temp = getRoot[temp];
			}
			
		}
		temp = edge[i].to;
		while (1)
		{
			if (getRoot[temp] == temp)
			{
				root2 = temp;
				break;
			}
			else
			{
				temp = getRoot[temp];
			}

		}
		if (root1 != root2)
		{
			getRoot[root1] = root2;
			sum += edge[i].weight;
		}
		
	}
	printf("%d\n", sum);
}